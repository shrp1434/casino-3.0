const auth = {
    async login() {
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;

        try {
            const data = await api.login(username, password);
            api.setToken(data.token);

            localStorage.setItem('user', JSON.stringify(data.user));

            this.hideAuth();
            app.showMain();
            app.loadUserData();

            this.showMessage('Login successful!', 'success');
        } catch (error) {
            this.showMessage(error.message, 'error');
        }
    },

    async register() {
        const username = document.getElementById('regUsername').value;
        const email = document.getElementById('regEmail').value;
        const password = document.getElementById('regPassword').value;

        if (username.length < 3) {
            this.showMessage('Username must be at least 3 characters', 'error');
            return;
        }

        if (password.length < 6) {
            this.showMessage('Password must be at least 6 characters', 'error');
            return;
        }

        try {
            await api.register(username, email, password);
            this.showMessage('Account created! Please check your email to verify your account.', 'success');
            setTimeout(() => this.showLogin(), 2000);
        } catch (error) {
            this.showMessage(error.message, 'error');
        }
    },

    logout() {
        api.clearToken();
        localStorage.removeItem('user');
        this.showAuth();
        app.hideMain();
    },

    showRegister() {
        document.getElementById('loginForm').classList.add('hidden');
        document.getElementById('registerForm').classList.remove('hidden');
    },

    showLogin() {
        document.getElementById('registerForm').classList.add('hidden');
        document.getElementById('loginForm').classList.remove('hidden');
    },

    showAuth() {
        document.getElementById('authScreen').classList.remove('hidden');
    },

    hideAuth() {
        document.getElementById('authScreen').classList.add('hidden');
    },

    showMessage(message, type) {
        const messageEl = document.getElementById('authMessage');
        messageEl.textContent = message;
        messageEl.className = type;
        messageEl.style.display = 'block';

        setTimeout(() => {
            messageEl.style.display = 'none';
        }, 5000);
    },

    checkAuth() {
        if (api.token) {
            this.hideAuth();
            app.showMain();
            app.loadUserData();
        }
    }
};
